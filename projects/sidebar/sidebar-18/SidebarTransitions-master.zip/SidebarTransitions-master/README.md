
Sidebar Transitions
=========
Some inspiration for transition effects for off-canvas navigations.

[Article on Codrops](http://tympanus.net/codrops/2013/08/28/transitions-for-off-canvas-navigations/)

[Demo](http://tympanus.net/Development/SidebarTransitions/)

[LICENSING & TERMS OF USE](http://tympanus.net/codrops/licensing/)
